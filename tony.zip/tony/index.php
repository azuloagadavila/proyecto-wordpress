<?php get_header(); ?>
index.php
<h1>Tony</h1>

<?php get_footer(); ?>